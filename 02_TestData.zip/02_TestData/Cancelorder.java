import java.util.*;
import java.io.*;  
import java.util.Scanner; 
public class Cancelorder{



public void doWork() throws Exception{


			//JDBCUtility jdbc1 = new JDBCUtility("jdbc:oracle:thin:@OR0145S.TST.KOHLS.COM:1521/OS0145_APP_OMSEC1N1.kohls.com","ofteam","ofteam");
			JDBCUtility jdbc1 = new JDBCUtility("jdbc:oracle:thin:@OR0145S.TST.KOHLS.COM:1521/OS0145_APP_OMSEC1N1.kohls.com","ofteam","ofteam");
			
            ArrayList<String> data = new ArrayList();
            
           /* String query = "select a.order_no,a.shipnode_key,a.shipment_key,b.shipment_line_key,b.item_id,DBMS_RANDOM.STRING('S',20) rstr" +
            "from sterling.yfs_shipment a,sterling.yfs_shipment_line b " +
                           "where a.shipment_key = b.shipment_key and " +
	"a.shipnode_key not in ('9961','9978','1368','1380','9987','840', '810', '830', '890', '860', '875', '855', '865', '885','1450','1508','1518','1519','1522','6666','1473','1450','1508') and status='1100.70.06.10' and extn_expiration_date > sysdate and a.order_no like 'WS%' order by rstr,a.order_no  ";*/
						   
       /*    String query = "select a.order_no,a.shipnode_key,a.shipment_key,b.shipment_line_key,b.item_id,DBMS_RANDOM.STRING('S',20) rstr "+
			  "from sterling.yfs_shipment a,sterling.yfs_shipment_line b "+
                           "where a.shipment_key = b.shipment_key and "+
	"a.shipnode_key not in ('9961','9978','1368','1380','9987','840', '810', '830', '890', '860', '875', '855', '865', '885','1450','1508','1518','1519','1522','6666','1473','1450','1508','1507','1510','1515','1516','1517','1527','1528') and status='1100.70.06.10' and extn_expiration_date > sysdate and a.delivery_method ='PICK' and a.shipment_key > '20160913' order by 2,3 ";*/
	String query = "select distinct c.release_no, a.prime_line_no, a.item_id, a.original_ordered_qty,c.EXTN_PICK_TICKET_NO,d.ORDER_NO,c.shipnode_key,d.order_header_key, DBMS_RANDOM.STRING('S',20) rstr  "+
	"from sterling.yfs_order_line  a inner join sterling.yfs_order_release_status b on a.order_line_key=b.order_line_key inner join sterling.yfs_order_release c on c.order_release_key=b.order_release_key inner join sterling.yfs_order_header d on d.order_header_key = a.order_header_key and d.order_header_key=c.order_header_key "+
	"where b.status in('3200.03','3300.001','3350.015','3200.04','3200.03','3300.003') and STATUS_QUANTITY > '0' and b.status_quantity =b.Total_quantity  and d.Order_No like 'CC2017090805%'  order by d.ORDER_NO, c.release_no ,rstr asc";
	
						   
            System.out.println(query);
            
            String fileName = "Cancelorder.txt";
            data = jdbc1.collectData(query);
		   
		   CreateCSV csv = new CreateCSV(fileName,false);  
		   csv.openFile();
		   
		   String previousOrder ="";boolean firstSkip = true;
		   String previousNodes ="";String previousorder_header_key ="";
		   String itemID_lines =""; String release_no_lines ="";
		   String shipnode ="";
		  String prime_line_no_key = "";
			for(String line: data){
				
				String[] details= line.split(",");
				String release_no = details[0];
				String prime_line_no = details[1];
				String itemID = details[2];
				String original_ordered_qty = details[3];
				String EXTN_PICK_TICKET_NO = details[4];
				String ORDER_NO = details[5];
				String shipnode_key =details[6];
				String order_header_key =details[7];
			   // shipnode = shipnode_key;
			
				if((previousorder_header_key.equalsIgnoreCase(order_header_key) || firstSkip)){
				//	if(previousNodes.equalsIgnoreCase(shipnode_key) || firstSkip){
			//	if(shipnode==previousNodes)
				//{
             // release_no_lines = release_no_lines+release_no+";";
				//	itemID_lines = itemID_lines + itemID +";" ;
					prime_line_no_key = prime_line_no_key+prime_line_no+";";
				//	release_no_lines=release_no_lines+release_no+";";
                        System.out.println("~"+ itemID_lines);
                  //  Shipment_lines = Shipment_lines+ shipment_line_key +";" ;
				//  String[] sReleaseNo = sReleaseNumber.split (";");
					System.out.println("If~"+ ORDER_NO);
					System.out.println("If~"+ shipnode_key);
					System.out.println("If~"+ previousNodes);
			//	}
				
                }else {
					
					Random r = new Random();
               String trackingNo = "" + r.nextInt(10) + r.nextInt(10) + r.nextInt(10) + r.nextInt(10) + r.nextInt(10) + r.nextInt(10) + r.nextInt(10) + r.nextInt(10) + r.nextInt(10) + r.nextInt(10) + r.nextInt(10) + r.nextInt(10) + r.nextInt(10) + r.nextInt(10);
    				String containerSCM = ("" + r.nextInt(9) + r.nextInt(9) + r.nextInt(9) + r.nextInt(9) + r.nextInt(9) + r.nextInt(9) + r.nextInt(9) + r.nextInt(9) + r.nextInt(9) + r.nextInt(9) + r.nextInt(9) + r.nextInt(9) + r.nextInt(9) + r.nextInt(9) + r.nextInt(9) + r.nextInt(9) + r.nextInt(9) + r.nextInt(9) + r.nextInt(9) + r.nextInt(9));
               System.out.println("!"+ itemID_lines);   
				 System.out.println("Else!"+ ORDER_NO);
				prime_line_no_key = prime_line_no_key.substring(0, prime_line_no_key.length()-1);
            //     itemID_lines = itemID_lines.substring(0, itemID_lines.length()-1);
				 System.out.println("!"+ itemID_lines);  
				//pReleaseNumber,pPrimeLineNumber,pItemiId,pOriginalOrderQuantity,pExtensionPickTicket,pOrderNumber,pShipNodeKey
			//	release_no_lines = release_no_lines.substring(0, release_no_lines.length()-1);
				String data2Write = prime_line_no_key+","+previousorder_header_key;
				
                 csv.writeFile(data2Write);
			//	 release_no_lines = release_no+";";
				 prime_line_no_key = prime_line_no +";" ;
           //      itemID_lines = itemID +";" ;
					
              }
		
			//	previousOrder = ORDER_NO;
				previousNodes = shipnode_key;
				previousorder_header_key = order_header_key;
			//	previousRelease = release_no;
                firstSkip = false;  
				
				System.out.println("Outside Else!"+ ORDER_NO);
				// System.out.println(data2Write[1]);
			}
			
			csv.closeFile();
		 
}


public static void main (String[] args){
	
	try{
	Cancelorder ob = new Cancelorder();
	ob.doWork();

	
try{  
  // Reading file and getting no. of files to be generated  
  String inputfile = "D:/StressADataSetup/MobiledataSetup/Cancelorder.txt"; //  Source File Name.  
 // double nol = 10000.0; //  No. of lines to be split and saved in each output file.  
  File file = new File(inputfile);  
  Scanner scanner = new Scanner(file);  
  int count = 0;  
  while (scanner.hasNextLine())   
  {  
   scanner.nextLine();  
   count++;  
  }  
  System.out.println("Lines in the file: " + count);     // Displays no. of lines in the input file.  

  double temp = (count/2);  
  int temp1=(int)temp;  
  int nof=0;  
  if(temp1==temp)  
  {  
   nof=temp1;  
  }  
  else  
  {  
   nof=temp1+1;  
  }  
  System.out.println("No. of data to be splited :"+nof); // Displays no. of files to be generated.  

  //---------------------------------------------------------------------------------------------------------  

  // Actual splitting of file into smaller files  

  FileInputStream fstream = new FileInputStream(inputfile); DataInputStream in = new DataInputStream(fstream);  

  BufferedReader br = new BufferedReader(new InputStreamReader(in)); String strLine;  

  for (int j=1;j<=2;j++)  
  {  
    String Udhaya ="";
   switch(j)
   {
	   
	   case 1:
	//   Udhaya = "//10.7.31.129/d$/BOPUS_NativeAPP_Jmeter/R28/TestData/STRESSA/APA";
	   break;
	   case 2:
	//   Udhaya = "//10.7.31.130/d$/BOPUS_NativeAPP_Jmeter/R28/TestData/STRESSA/APA";
	   break;
   }

   
   FileWriter fstream1 = new FileWriter("D:/StressADataSetup/MobiledataSetup/APA_S05_EFC.csv");     // Destination File Location  
   BufferedWriter out = new BufferedWriter(fstream1);   
   for (int i=1;i<=nof;i++)  
   {  
    strLine = br.readLine();   
    if (strLine!= null)  
    {  
     out.write(strLine);   
     if(i!=nof)  
     {  
      out.newLine();  
     }  
    }  
   }  
   out.close();  
  }  

  in.close();  
 }catch (Exception e)  
 {  
  System.err.println("Error: " + e.getMessage());  
 }  
	
	}catch(Exception e){
		
		e.printStackTrace();
	}
}

}