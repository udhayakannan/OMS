import java.util.*;
import java.io.*;  
import java.util.Scanner; 

public class SFSChatbot{



public void doWork() throws Exception{


			JDBCUtility jdbc1 = new JDBCUtility("jdbc:oracle:thin:@OR0145S.TST.KOHLS.COM:1521/OS0145_APP_OMSEC1N1.kohls.com","ofteam","ofteam");
			
            ArrayList<String> data = new ArrayList();
            
            String query = "select a.order_no,a.shipnode_key,a.shipment_key,b.shipment_line_key,b.item_id,DBMS_RANDOM.STRING('S',20) rstr " +
                           "from sterling.yfs_shipment a,sterling.yfs_shipment_line b " +
                           "where a.shipment_key = b.shipment_key and " +
	"a.shipnode_key not in ('9961','9978','1368','1380','9987','840','1529', '810', '830', '890', '860', '875', '855', '865', '885','1450','1508','1518','1519','1522','6666','1473','1450','1508','1507','1510','1515','1516','1517','1527','1528') and status='1100.70.06.10' and b.order_no like 'C2017090802%' and a.delivery_method ='SHP'  order by 2,3";
						   
            //and extn_expiration_date > sysdate
            
           System.out.println(query);
            
            
            String fileName = "SFSChatbot.txt";
            data = jdbc1.collectData(query);
		   
		   CreateCSV csv = new CreateCSV(fileName,false);  
		   csv.openFile();
		   
		   String previousOrder ="";boolean firstSkip = true;
		   String previousNodes ="";String previousQty ="";
		   String itemID_lines ="";
		   String Shipment_lines ="";
		   String Password ="Password";
		   String pUserName ="";
		   
			for(String line: data){
				
				String[] details= line.split(",");
				String order_no = details[0];
				String shipnode_key = details[1];
				String shipment_key = details[2];
				String shipment_line_key = details[3];
				String itemID = details[4];
				String UserName =shipnode_key;
				int length = shipnode_key.length();
				int i;
				int nlength =(6)-(length);
				UserName ="1";
				if (length != 5)
				{
			    for (i=1;i<nlength;i++)
				{
					UserName =UserName +"0";
						
				}
				UserName = UserName + shipnode_key;
				}
				else 
				{
					UserName = "10" + shipnode_key;
				}
				
				if(previousQty.equalsIgnoreCase(shipment_key) || firstSkip){
              
					itemID_lines = itemID_lines+ itemID +";" ;
                        // System.out.println("~"+ itemID_lines);
                    Shipment_lines = Shipment_lines+ shipment_line_key +";" ;
					//System.out.println("~"+ Shipment_lines);
						 
                }else {
               //  System.out.println("!"+ itemID_lines);   
				// System.out.println("!"+ Shipment_lines);
                 itemID_lines = itemID_lines.substring(0, itemID_lines.length()-1);
				 Shipment_lines = Shipment_lines.substring(0, Shipment_lines.length()-1);
				 String data2Write = previousNodes+","+pUserName+","+Password+","+previousOrder+","+previousQty+","+Shipment_lines +","+itemID_lines;
                 csv.writeFile(data2Write);
				 Shipment_lines = shipment_line_key +";" ;
                 itemID_lines = itemID +";" ;
				
              }
			  
				previousOrder = order_no;
				previousNodes = shipnode_key;
				previousQty = shipment_key;
				pUserName = UserName;
				firstSkip = false;  
				
				
				
			}
			
			csv.closeFile();
			
}


public static void main (String[] args){
	
	try{
	SFSChatbot ob = new SFSChatbot();
	ob.doWork();

		}catch(Exception e){
		
		e.printStackTrace();
	}
}

}